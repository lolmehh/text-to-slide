Het exe bestand werkt om een of andere reden niet zou u het python bestand met de omschrijving in de andere readme willen gebruiken.

lukt het u niet om te runnen gebruik dan de github of mail Maurits